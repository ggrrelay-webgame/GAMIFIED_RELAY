import { AppState, AttemptLog, SurveyResponse } from '../types';

export interface SyncResponse {
  success: boolean;
  appState: AppState;
  logData: AttemptLog[];
  surveys?: SurveyResponse[];
  lastUpdated?: string;
  error?: string;
}

// Generate unique signature for log deduplication
export function getLogSignature(log: AttemptLog): string {
  if (log.id && log.id.trim()) {
    return log.id.trim();
  }
  return `${log.ts}_${log.phase}_${log.team}_${log.player}_${log.questionNumber}_${log.prompt?.slice(0, 20)}`;
}

// Merge logs deduplicated
export function mergeLogs(existing: AttemptLog[], incoming: AttemptLog[]): AttemptLog[] {
  const map = new Map<string, AttemptLog>();
  for (const log of existing) {
    map.set(getLogSignature(log), log);
  }
  for (const log of incoming) {
    if (log && log.team && log.phase) {
      const key = getLogSignature(log);
      if (!map.has(key)) {
        map.set(key, log);
      }
    }
  }
  return Array.from(map.values()).sort(
    (a, b) => new Date(a.ts).getTime() - new Date(b.ts).getTime()
  );
}

// Merge completedToday from two sources (union of sets)
export function mergeCompletedToday(
  a: Record<string, number[]>,
  b: Record<string, number[]>
): Record<string, number[]> {
  const result: Record<string, number[]> = { ...(a || {}) };
  for (const [phaseKey, doneList] of Object.entries(b || {})) {
    const prevList = result[phaseKey] || [];
    result[phaseKey] = Array.from(new Set([...prevList, ...(Array.isArray(doneList) ? doneList : [])]));
  }
  return result;
}

// Fetch current cloud state
export async function fetchCloudSync(): Promise<SyncResponse | null> {
  try {
    const res = await fetch('/api/sync', {
      method: 'GET',
      headers: { Accept: 'application/json' },
    });
    if (!res.ok) return null;
    const data = await res.json();
    return data;
  } catch (err) {
    // Offline or network unavailable
    return null;
  }
}

// Push local updates to cloud server
export async function pushCloudSync(payload: {
  clientState?: Partial<AppState>;
  newLogs?: AttemptLog[];
  logData?: AttemptLog[];
  surveys?: SurveyResponse[];
  newSurveys?: SurveyResponse[];
}): Promise<SyncResponse | null> {
  try {
    const res = await fetch('/api/sync', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Accept: 'application/json',
      },
      body: JSON.stringify(payload),
    });
    if (!res.ok) return null;
    const data = await res.json();
    return data;
  } catch (err) {
    // Offline or network unavailable
    return null;
  }
}

// Reset cloud database (e.g. from teacher panel)
export async function resetCloudDatabase(appState: AppState, logData: AttemptLog[]): Promise<SyncResponse | null> {
  try {
    const res = await fetch('/api/reset', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Accept: 'application/json',
      },
      body: JSON.stringify({ appState, logData }),
    });
    if (!res.ok) return null;
    return await res.json();
  } catch {
    return null;
  }
}
