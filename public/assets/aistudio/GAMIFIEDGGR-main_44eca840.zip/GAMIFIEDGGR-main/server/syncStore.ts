import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DATA_FILE = path.resolve(__dirname, '..', 'data', 'ggr_database.json');

export interface AppStateData {
  pin: string;
  currentPhaseIndex: number;
  completedToday: Record<string, number[]>;
  groups: Array<{
    name: string;
    members: string[];
  }>;
  surveyResponses?: any[];
}

export interface AttemptLogData {
  id: string;
  ts: string;
  phase: string;
  phaseLabel?: string;
  weekLabel?: string;
  team: string;
  player: string;
  runnerIndex?: number;
  roleAtTurn?: string;
  questionNumber?: number;
  prompt: string;
  chosen: string;
  correctAnswer?: string;
  correct: boolean;
}

export interface DatabaseSchema {
  appState: AppStateData;
  logData: AttemptLogData[];
  lastUpdated?: string;
}

const DEFAULT_STATE: AppStateData = {
  pin: '1234',
  currentPhaseIndex: 0,
  completedToday: {
    pretest: [],
    session1: [],
    session2: [],
    session3: [],
    session4: [],
    posttest: [],
  },
  groups: [0, 1, 2, 3].map((i) => ({
    name: `Team ${i + 1}`,
    members: [1, 2, 3, 4, 5].map((n) => `Runner ${n}`),
  })),
  surveyResponses: [],
};

let memoryStore: DatabaseSchema = {
  appState: DEFAULT_STATE,
  logData: [],
  lastUpdated: new Date().toISOString(),
};

// Initial load from file
export function loadDatabase(): DatabaseSchema {
  try {
    if (fs.existsSync(DATA_FILE)) {
      const raw = fs.readFileSync(DATA_FILE, 'utf-8');
      const parsed = JSON.parse(raw);
      if (parsed && parsed.appState) {
        memoryStore = {
          appState: {
            ...DEFAULT_STATE,
            ...parsed.appState,
            completedToday: {
              ...DEFAULT_STATE.completedToday,
              ...(parsed.appState.completedToday || {}),
            },
          },
          logData: Array.isArray(parsed.logData) ? parsed.logData : [],
          lastUpdated: parsed.lastUpdated || new Date().toISOString(),
        };
        return memoryStore;
      }
    }
  } catch (err) {
    console.error('[SYNC] Failed to read database from file, using memory store:', err);
  }
  return memoryStore;
}

// Save to disk helper
export function saveDatabase(data: DatabaseSchema): void {
  memoryStore = data;
  try {
    const dir = path.dirname(DATA_FILE);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2), 'utf-8');
  } catch (err) {
    console.error('[SYNC] Failed to save database to file:', err);
  }
}

// Generate unique signature for log deduplication
function getLogKey(log: AttemptLogData): string {
  if (log.id && log.id.trim()) {
    return log.id.trim();
  }
  return `${log.ts}_${log.phase}_${log.team}_${log.player}_${log.questionNumber}_${log.prompt?.slice(0, 20)}`;
}

// Core merge function for multi-device sync
export function mergeDatabase(payload: {
  clientState?: Partial<AppStateData>;
  newLogs?: AttemptLogData[];
  logData?: AttemptLogData[];
  surveys?: any[];
  newSurveys?: any[];
}): DatabaseSchema {
  const current = loadDatabase();
  const now = new Date().toISOString();

  // 1. Merge completedToday (union of all completed team indices)
  const mergedCompleted: Record<string, number[]> = {
    ...current.appState.completedToday,
  };

  if (payload.clientState?.completedToday) {
    for (const [phaseKey, clientDone] of Object.entries(payload.clientState.completedToday)) {
      const serverDone = mergedCompleted[phaseKey] || [];
      const combined = Array.from(new Set([...serverDone, ...(Array.isArray(clientDone) ? clientDone : [])]));
      mergedCompleted[phaseKey] = combined;
    }
  }

  // 2. Merge groups if client updated team or runner names
  let mergedGroups = current.appState.groups;
  if (Array.isArray(payload.clientState?.groups) && payload.clientState.groups.length === 4) {
    // Check if client groups have non-default names
    const hasCustomGroupData = payload.clientState.groups.some(
      (g) => g.name && g.members && g.members.length === 5
    );
    if (hasCustomGroupData) {
      mergedGroups = payload.clientState.groups.map((g, idx) => ({
        name: g.name || `Team ${idx + 1}`,
        members: Array.isArray(g.members) && g.members.length === 5 ? g.members : current.appState.groups[idx].members,
      }));
    }
  }

  // 3. Current Phase Index (keep teacher or highest valid phase)
  let mergedPhaseIndex = current.appState.currentPhaseIndex;
  if (typeof payload.clientState?.currentPhaseIndex === 'number') {
    mergedPhaseIndex = Math.max(mergedPhaseIndex, payload.clientState.currentPhaseIndex);
  }

  // 4. Merge Surveys
  const existingSurveys = current.appState.surveyResponses || [];
  const incomingSurveys = [
    ...(payload.surveys || []),
    ...(payload.newSurveys || []),
    ...(payload.clientState?.surveyResponses || []),
  ];
  const surveyMap = new Map<string, any>();
  for (const s of existingSurveys) {
    const key = s.id || `${s.teamName}_${s.timestamp}`;
    surveyMap.set(key, s);
  }
  for (const s of incomingSurveys) {
    if (s && s.teamName) {
      const key = s.id || `${s.teamName}_${s.timestamp}`;
      if (!surveyMap.has(key)) {
        surveyMap.set(key, s);
      }
    }
  }
  const mergedSurveys = Array.from(surveyMap.values());

  // 5. Merge Logs (strictly deduplicated so no duplicate questions or attempts)
  const existingLogs = current.logData || [];
  const incomingLogs = [...(payload.newLogs || []), ...(payload.logData || [])];
  const logMap = new Map<string, AttemptLogData>();

  for (const log of existingLogs) {
    logMap.set(getLogKey(log), log);
  }
  for (const log of incomingLogs) {
    if (log && log.team && log.phase) {
      const key = getLogKey(log);
      if (!logMap.has(key)) {
        logMap.set(key, log);
      }
    }
  }

  const mergedLogs = Array.from(logMap.values()).sort((a, b) => {
    return new Date(a.ts).getTime() - new Date(b.ts).getTime();
  });

  const updatedDatabase: DatabaseSchema = {
    appState: {
      pin: payload.clientState?.pin || current.appState.pin || '1234',
      currentPhaseIndex: mergedPhaseIndex,
      completedToday: mergedCompleted,
      groups: mergedGroups,
      surveyResponses: mergedSurveys,
    },
    logData: mergedLogs,
    lastUpdated: now,
  };

  saveDatabase(updatedDatabase);
  return updatedDatabase;
}

// Reset or Seed
export function resetDatabase(newState?: Partial<AppStateData>, sampleLogs?: AttemptLogData[]): DatabaseSchema {
  const resetDb: DatabaseSchema = {
    appState: {
      ...DEFAULT_STATE,
      ...(newState || {}),
      completedToday: (newState && newState.completedToday) || DEFAULT_STATE.completedToday,
    },
    logData: sampleLogs || [],
    lastUpdated: new Date().toISOString(),
  };
  saveDatabase(resetDb);
  return resetDb;
}

// Initial load on import
loadDatabase();
